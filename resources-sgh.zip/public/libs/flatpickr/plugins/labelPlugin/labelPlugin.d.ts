import { Plugin } from "../../types/options";
declare function labelPlugin(): Plugin;
export default labelPlugin;
